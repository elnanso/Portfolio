Nans Lafitte SIO SLAM 19062024

le point d'entré du site est : login.php

- le site offre un moyen de créer un utilisateur via "Vous n'avez pas de compte ?"
- une fois le compte crée, l'authentification mène a une table de contact, propre a l'utilisateur (clef étrangère user_id permet de select uniquement les contacts de l'user connecté)
- on peut bien évidemment ajouter des contacts 
- pas de cookies, manque de temp car je maitrise a moitié ce concept
